import type { Page } from "@playwright/test";
import { expect, signIn, test } from "./fixtures";
import type { Strings } from "./strings";

// Setup Studio (supabase/seed.sql) is reserved for these journeys, so the
// branches they create and archive never touch the switcher tests.
const HAWALLY = "00000000-0000-4000-a000-000000000004";
const JAHRA = "00000000-0000-4000-a000-000000000005";

const branchSwitcher = (page: Page, s: Strings) => page.getByRole("banner").getByRole("combobox", { name: s.branch });

test("owner sets up a branch end to end", async ({ page, s, appLocale }) => {
  const suffix = `${appLocale}-${Date.now().toString(36)}`;
  const nameEn = `Fintas ${suffix}`;
  const nameAr = `الفنطاس ${suffix}`;
  const shownName = appLocale === "ar" ? nameAr : nameEn;

  await page.goto("/login");
  await signIn(page, s, "setup-owner@spacorner.test");
  await expect(page.getByRole("heading", { name: s.finishSettingUp })).toBeVisible();

  // Hub -> branches -> new branch.
  await page.getByRole("link", { name: s.settings }).click();
  await page.getByRole("link", { name: s.branches, exact: true }).click();
  await page.getByRole("link", { name: s.addBranch }).click();
  await page.getByLabel(s.branchNameEn).fill(nameEn);
  await page.getByLabel(s.branchNameAr).fill(nameAr);
  await page.getByLabel(s.address).fill("Block 4, Street 12");
  await page.getByLabel(s.phone).fill("+965 2222 3333");
  await page.getByLabel(s.invoicePrefix).fill("FNT");
  await page.getByRole("button", { name: s.createBranch }).click();
  await expect(page.getByText(s.branchCreated)).toBeVisible();
  await expect(page).toHaveURL(/\/settings\/branches\/[\w-]+\/hours/);
  await expect(page.getByRole("heading", { level: 1, name: shownName })).toBeVisible();

  // The new branch is in the switcher straight away.
  await expect(branchSwitcher(page, s).locator("option", { hasText: shownName })).toHaveCount(1);

  // Thursday: split day 10:00-14:00 plus an overnight 18:00-02:00, shown in the branch's 12-hour format.
  const thursday = page.getByRole("group", { name: s.thursday });
  await thursday.getByLabel(s.closes).first().fill("14:00");
  await thursday.getByRole("button", { name: s.splitDay }).click();
  await thursday.getByLabel(s.opens).nth(1).fill("18:00");
  await thursday.getByLabel(s.closes).nth(1).fill("02:00");
  await expect(thursday.getByTestId("hours-preview").nth(1)).toContainText(s.pm6to2am);
  await expect(thursday.getByText(s.closesNextDay)).toBeVisible();

  // A zero-length interval is rejected at the field and blocks saving.
  const friday = page.getByRole("group", { name: s.friday });
  await friday.getByLabel(s.closes).first().fill("14:00");
  await expect(friday.getByText(s.zeroLength)).toBeVisible();
  await expect(page.getByRole("button", { name: s.saveHours })).toBeDisabled();
  await friday.getByLabel(s.closes).first().fill("22:00");
  await expect(friday.getByText(s.zeroLength)).toHaveCount(0);

  await page.getByRole("button", { name: s.saveHours }).click();
  await expect(page.getByText(s.hoursSaved)).toBeVisible();

  // Saved hours come back from the database in branch-local time.
  await page.reload();
  const thursdayAfter = page.getByRole("group", { name: s.thursday });
  await expect(thursdayAfter.getByTestId("hours-preview")).toHaveCount(2);
  await expect(thursdayAfter.getByTestId("hours-preview").nth(1)).toContainText(s.pm6to2am);
  await expect(thursdayAfter.getByText(s.closesNextDay)).toBeVisible();

  // Receipt text, paired English and Arabic.
  await page.getByRole("link", { name: s.invoicingTab }).click();
  await page.getByLabel(s.headerEn).fill("Welcome to Fintas");
  await page.getByLabel(s.headerAr).fill("أهلاً بكم في الفنطاس");
  await page.getByLabel(s.footerEn).fill("Thank you for visiting");
  await page.getByLabel(s.footerAr).fill("شكراً لزيارتكم");
  await page.getByRole("button", { name: s.save }).click();
  await expect(page.getByText(s.invoicingSaved)).toBeVisible();

  // Checkout methods.
  await page.getByRole("link", { name: s.methodsTab }).click();
  await page.getByLabel(s.bankTransfer).check();
  await page.getByLabel(s.cash).uncheck();
  await page.getByRole("button", { name: s.save }).click();
  await expect(page.getByText(s.methodsSaved)).toBeVisible();

  // Tips.
  await page.getByRole("link", { name: s.tipsTab }).click();
  await page.getByLabel(s.askTip).check();
  await page.getByLabel(s.tipPresets).fill("5, 10, 15");
  await page.getByRole("button", { name: s.save }).click();
  await expect(page.getByText(s.tipsSaved)).toBeVisible();

  // Everything persisted.
  await page.reload();
  await expect(page.getByLabel(s.askTip)).toBeChecked();
  await expect(page.getByLabel(s.tipPresets)).toHaveValue("5, 10, 15");
  await page.getByRole("link", { name: s.methodsTab }).click();
  await expect(page.getByLabel(s.bankTransfer)).toBeChecked();
  await expect(page.getByLabel(s.cash)).not.toBeChecked();
  await page.getByRole("link", { name: s.invoicingTab }).click();
  await expect(page.getByLabel(s.headerAr)).toHaveValue("أهلاً بكم في الفنطاس");

  // Archive: gone from the switcher, still listed (badged) in settings.
  await page.getByRole("button", { name: s.archiveBranch }).click();
  await page.getByRole("alertdialog").getByRole("button", { name: s.archive, exact: true }).click();
  await expect(page.getByText(s.branchArchived)).toBeVisible();
  await expect(branchSwitcher(page, s).locator("option", { hasText: shownName })).toHaveCount(0);
  await expect(branchSwitcher(page, s).locator("option", { hasText: s.hawally })).toHaveCount(1);

  await page.getByRole("link", { name: s.branches }).first().click();
  const row = page.getByRole("row", { name: new RegExp(shownName) });
  await expect(row).toContainText(s.archived);
});

test("a receptionist can't reach settings", async ({ page, s }) => {
  await page.goto("/login");
  await signIn(page, s, "setup-reception@spacorner.test");
  await expect(page.getByRole("heading", { name: s.welcome("Reem Hawally") })).toBeVisible();
  await expect(page.getByRole("link", { name: s.settings })).toHaveCount(0);

  await page.goto(`/settings/branches/${HAWALLY}/details`);
  await expect(page.getByRole("heading", { name: s.forbidden })).toBeVisible();
  await page.goto("/setup");
  await expect(page.getByRole("heading", { name: s.forbidden })).toBeVisible();
});

test("a manager sees only their branch: details read-only, hours editable", async ({ page, s }) => {
  await page.goto("/login");
  await signIn(page, s, "setup-manager@spacorner.test");
  await page.getByRole("link", { name: s.settings }).click();
  await page.getByRole("link", { name: s.branches, exact: true }).click();

  const rows = page.getByRole("row");
  await expect(rows.filter({ hasText: s.hawally })).toHaveCount(1);
  await expect(rows.filter({ hasText: s.jahra })).toHaveCount(0);
  await expect(page.getByRole("link", { name: s.addBranch })).toHaveCount(0);

  await rows.filter({ hasText: s.hawally }).getByRole("link").click();
  await expect(page.getByText(s.ownerOnlyDetails)).toBeVisible();
  await expect(page.getByLabel(s.branchNameEn)).toHaveAttribute("readonly", "");
  await expect(page.getByRole("button", { name: s.save })).toHaveCount(0);

  await page.getByRole("link", { name: s.hoursTab }).click();
  await page.getByRole("button", { name: s.saveHours }).click();
  await expect(page.getByText(s.hoursSaved)).toBeVisible();

  // Another branch of the same business is out of scope.
  await page.goto(`/settings/branches/${JAHRA}/details`);
  await expect(page.getByRole("heading", { name: s.branchNotFound })).toBeVisible();
});
