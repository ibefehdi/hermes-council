import { expect, signIn, test } from "./fixtures";
import { acceptInvite, newPersonPage, unique } from "./memberFlows";
import { SETUP_BRANCH, addStaff, openStaffList, staffRow } from "./staffFlows";

// Setup Studio (supabase/seed.sql) gets fresh staff each run; SpaCorner's
// seeded staff are only read. The seed owner never signs out (see members.spec.ts).

test("an owner adds a staff member without a login at two branches, found in both lists and by Arabic search", async ({
  page,
  s,
  appLocale,
}) => {
  const id = unique(appLocale);
  const nameEn = `Amal ${id}`;
  const nameAr = `أَمَل الأحمد ${id}`;

  await page.goto("/login");
  await signIn(page, s, "setup-owner@spacorner.test");
  await openStaffList(page, s, SETUP_BRANCH.hawally);

  await page.getByRole("link", { name: s.addStaffMember }).click();
  await page.getByRole("checkbox", { name: s.hawally, exact: true }).uncheck();
  await page.getByRole("button", { name: s.addStaffMember }).click();
  await expect(page.getByText(s.nameRequired)).toBeVisible();
  await page.getByLabel(s.fullNameEn).fill(nameEn);
  await page.getByRole("button", { name: s.addStaffMember }).click();
  await expect(page.getByText(s.chooseBranch)).toBeVisible();
  await page.goto(`/team/staff?branch=${SETUP_BRANCH.hawally}`);

  await addStaff(page, s, { nameEn, nameAr, branches: [s.hawally, s.jahra], defaultBranch: s.jahra });
  await expect(page.getByText(s.noLogin)).toBeVisible();
  await expect(page.getByRole("checkbox", { name: s.bookableAt(s.jahra) })).toBeChecked();

  await page.getByRole("checkbox", { name: s.bookableAt(s.hawally) }).uncheck();
  await page.getByLabel(s.jobTitleEn).fill("Therapist");
  await page.getByRole("button", { name: s.saveChanges }).click();
  await expect(page.getByText(s.changesSaved)).toBeVisible();

  await openStaffList(page, s, SETUP_BRANCH.hawally);
  await expect(staffRow(page, id)).toBeVisible();
  await openStaffList(page, s, SETUP_BRANCH.jahra);
  await expect(staffRow(page, id)).toBeVisible();

  // Unvowelled, plain-alef query against the vowelled name (ADR-40).
  await page.getByLabel(s.searchStaff).fill(`امل الاحمد ${id}`);
  await expect(page).toHaveURL(/q=/);
  await expect(staffRow(page, id)).toBeVisible();
  await expect(page.getByRole("row")).toHaveCount(2);
  await page.getByLabel(s.searchStaff).fill(`nobody-${id}`);
  await expect(page.getByRole("link", { name: new RegExp(id) })).toHaveCount(0);
});

test("a staff member with a login is invited and then sees only their own day across their branches", async ({
  page,
  browser,
  request,
  s,
  appLocale,
}) => {
  const id = unique(appLocale);
  const email = `staff-${id}@spacorner.test`;
  const nameEn = `Lina ${id}`;

  await page.goto("/login");
  await signIn(page, s, "setup-owner@spacorner.test");
  await openStaffList(page, s, SETUP_BRANCH.hawally);
  await addStaff(page, s, { nameEn, nameAr: `لينا ${id}`, email, branches: [s.hawally, s.jahra] });

  await page.getByRole("button", { name: s.inviteToSignIn }).click();
  await expect(page.getByText(s.invitationSent, { exact: true })).toBeVisible();
  await expect(page.getByText(s.invitationSentTo(email))).toBeVisible();

  const person = await newPersonPage(browser, appLocale);
  await acceptInvite(person, request, s, email, `Glow-${id}`);
  await expect(person.getByRole("link", { name: s.team, exact: true })).toHaveCount(0);
  await person.getByRole("link", { name: s.myDay }).click();
  await expect(person.getByRole("heading", { level: 1, name: s.myDay })).toBeVisible();
  const branches = person.getByRole("table", { name: s.yourBranches });
  await expect(branches).toContainText(s.hawally);
  await expect(branches).toContainText(s.jahra);
  await expect(branches.getByRole("row")).toHaveCount(3);

  await person.goto("/team/staff");
  await expect(person.getByRole("heading", { name: s.forbidden })).toBeVisible();
  await person.context().close();

  await page.reload();
  await expect(page.getByText(s.canSignIn)).toBeVisible();
});

test("a receptionist sees their branch's team read-only", async ({ page, s }) => {
  await page.goto("/login");
  await signIn(page, s, "reception@spacorner.test");
  await openStaffList(page, s);
  await expect(page.getByRole("link", { name: s.addStaffMember })).toHaveCount(0);
  await expect(page.getByRole("row")).toHaveCount(4);

  await page.getByRole("link", { name: s.seededAmal }).click();
  await expect(page.getByText(s.staffReadOnly)).toBeVisible();
  await expect(page.getByLabel(s.fullNameEn)).toHaveAttribute("readonly", "");
  await expect(page.getByRole("button", { name: s.saveChanges })).toHaveCount(0);
  await expect(page.getByRole("button", { name: s.inviteToSignIn })).toHaveCount(0);
});

test("a member without a staff profile gets an explanation on My day", async ({ page, s }) => {
  await page.goto("/login");
  await signIn(page, s, "manager@spacorner.test");
  await page.getByRole("link", { name: s.myDay }).click();
  await expect(page.getByRole("heading", { name: s.noStaffProfile })).toBeVisible();
});
