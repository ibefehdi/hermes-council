import { test as base, expect, type Page } from "@playwright/test";
import { strings, type AppLocale, type Strings } from "./strings";

export type AppLocaleOptions = { appLocale: AppLocale };

type Fixtures = {
  /** UI strings of the project's language. */
  s: Strings;
  /** UI strings of the other language (after switching). */
  other: Strings;
};

export const test = base.extend<Fixtures & AppLocaleOptions>({
  appLocale: ["en", { option: true }],
  page: async ({ page, appLocale }, use) => {
    // Starts the device in the project language; a later in-app switch still wins.
    await page.addInitScript((locale) => {
      if (window.localStorage.getItem("glowdesk.locale") === null) {
        window.localStorage.setItem("glowdesk.locale", locale);
      }
    }, appLocale);
    await use(page);
  },
  s: async ({ appLocale }, use) => {
    await use(strings[appLocale]);
  },
  other: async ({ appLocale }, use) => {
    await use(strings[appLocale === "en" ? "ar" : "en"]);
  },
});

export { expect };

export const PASSWORD = "password123";

export async function expectDocumentLocale(page: Page, s: Strings) {
  await expect(page.locator("html")).toHaveAttribute("lang", s.lang);
  await expect(page.locator("html")).toHaveAttribute("dir", s.dir);
}

/** The shell topbar's account menu button; the sign-in page's header has none. */
const accountMenu = (page: Page) => page.getByRole("banner").locator('button[aria-haspopup="dialog"]');

/**
 * Signs in from the login page and waits until the session has landed: the shell's topbar, or with
 * `shell: false` (a login without a membership, sent to a standalone page) the sign-in form gone.
 */
export async function signIn(page: Page, s: Strings, email: string, password = PASSWORD, { shell = true } = {}) {
  const emailField = page.getByLabel(s.email);
  const passwordField = page.getByLabel(s.password, { exact: true });
  const submit = page.getByRole("button", { name: s.signIn });
  await emailField.fill(email);
  await passwordField.fill(password);
  await expect(emailField).toHaveValue(email);
  await expect(passwordField).toHaveValue(password);
  await submit.click();
  await (shell ? expect(accountMenu(page)).toBeVisible() : expect(submit).toHaveCount(0));
}

/** Opens the topbar account menu (theme switcher, sign out) if it is closed. */
export async function openAccountMenu(page: Page) {
  const trigger = accountMenu(page);
  if ((await trigger.getAttribute("aria-expanded")) !== "true") await trigger.click();
}

export async function signOut(page: Page, s: Strings) {
  // Inside the shell, sign out lives in the account menu; standalone pages show it directly.
  if ((await accountMenu(page).count()) > 0) {
    await openAccountMenu(page);
  }
  await page.getByRole("button", { name: s.signOut }).click();
  await expect(page).toHaveURL(/\/login/);
}
