import type { Locator, Page } from "@playwright/test";
import { addDays } from "./blockedTimeFlows";
import { assignToBranch, book, createClient, createService, createStaff, kuwait, setBranchPrice } from "./bookingFixtures";
import { expect, signIn, test } from "./fixtures";
import { unique } from "./memberFlows";
import { kuwaitToday } from "./shiftFlows";
import { SETUP_BRANCH } from "./staffFlows";
import type { Strings } from "./strings";

// Moving appointments at Setup Studio: drag and keyboard on the day view, and
// the Move dialog for another branch. Every run books its own visits.

const EVENT = "[data-event-id]:not([id^='time-grid-event-copy-'])";
// BookingCalendar draws 24px per slot; Hawally keeps the default 15-minute step.
const PX_PER_MINUTE = 24 / 15;

type Request = Parameters<typeof createService>[0];

async function twoBooked(request: Request, id: string, day: string) {
  const serviceId = await createService(request, { en: `Facial ${id}`, ar: `تنظيف بشرة ${id}` }, { duration: 60 });
  const shifts = [{ day, starts: "09:00", ends: "22:00" }];
  const monaId = await createStaff(request, {
    name: { en: `Mona ${id}`, ar: `منى ${id}` },
    branchId: SETUP_BRANCH.hawally,
    serviceIds: [serviceId],
    shifts,
  });
  const noorId = await createStaff(request, {
    name: { en: `Noor ${id}`, ar: `نور ${id}` },
    branchId: SETUP_BRANCH.hawally,
    serviceIds: [serviceId],
    shifts,
  });
  const saraId = await createClient(request, { firstName: "Sara", lastName: id, firstNameAlt: "سارة", lastNameAlt: id });
  const linaId = await createClient(request, { firstName: "Lina", lastName: id, firstNameAlt: "لينا", lastNameAlt: id });
  for (const [clientId, staffId] of [
    [saraId, monaId],
    [linaId, noorId],
  ] as const) {
    await book(request, "setup-reception@spacorner.test", {
      branchId: SETUP_BRANCH.hawally,
      clientId,
      items: [{ service_id: serviceId, staff_id: staffId, starts_at: kuwait(day, "15:00") }],
    });
  }
  return { monaId, noorId };
}

async function openDay(page: Page, s: Strings, day: string, staff: string[]) {
  await page.goto("/login");
  await signIn(page, s, "setup-reception@spacorner.test");
  await expect(page).toHaveURL(/\?branch=/);
  await page.goto(`/calendar?branch=${SETUP_BRANCH.hawally}&date=${day}&staff=${encodeURIComponent(JSON.stringify(staff))}`);
  return page.getByRole("region", { name: s.appointmentsByStaff });
}

// The card's own times, not its pixel offset: other runs' shifts at Hawally can widen the
// grid's hours at any refetch (realtime included), which moves every card down.
const timeOf = (event: Locator) => event.locator(".gd-event-time");
const hours = (start: string, end: string) => new RegExp(`${start}\\s*–\\s*${end}`);

async function box(locator: Locator) {
  const found = await locator.boundingBox();
  if (!found) throw new Error("not on screen");
  return found;
}

/** Drags `event` into `column`, `minutes` later than it started, from on-screen boxes (mirrored in RTL). */
async function drag(page: Page, event: Locator, column: Locator, minutes: number) {
  await event.scrollIntoViewIfNeeded();
  const from = await box(event);
  const to = await box(column);
  const startX = from.x + from.width / 2;
  const startY = from.y + Math.min(12, from.height / 2);
  await page.mouse.move(startX, startY);
  await page.mouse.down();
  await page.waitForTimeout(250);
  await page.mouse.move(to.x + to.width / 2, startY + minutes * PX_PER_MINUTE, { steps: 20 });
  await page.mouse.up();
}

test("a drag onto a taken time rolls back with a conflict, a suggested time moves it, and Undo puts it back", async ({
  page,
  request,
  s,
  appLocale,
}) => {
  const id = unique(appLocale);
  const day = addDays(kuwaitToday(), 1);
  const sara = appLocale === "ar" ? `سارة ${id}` : `Sara ${id}`;
  const { monaId, noorId } = await twoBooked(request, id, day);

  const byStaff = await openDay(page, s, day, [monaId, noorId]);
  const column = (staffId: string) => byStaff.locator(`.gd-resource-column[data-resource-id="${staffId}"]`);
  const saraWith = (staffId: string) => column(staffId).locator(EVENT).filter({ hasText: sara });
  await expect(saraWith(monaId)).toBeVisible();

  // Noor's column follows Mona's in reading order: to the left in Arabic.
  const [monaBox, noorBox] = [await box(column(monaId)), await box(column(noorId))];
  expect(appLocale === "ar" ? noorBox.x < monaBox.x : noorBox.x > monaBox.x).toBe(true);

  // Noor is busy at 15:00: the move is refused and Sara goes back to Mona.
  await drag(page, saraWith(monaId), column(noorId), 0);
  const toast = page.getByRole("alert").filter({ hasText: s.couldNotMove(sara) });
  await expect(toast).toBeVisible();
  await expect(saraWith(monaId)).toBeVisible();
  await expect(saraWith(noorId)).toHaveCount(0);

  // One of the free times nearby moves her there.
  await toast.getByRole("listitem").first().getByRole("button").click();
  await expect(page.getByText(s.movedTo(sara))).toBeVisible();
  await expect(saraWith(noorId)).toBeVisible();

  await page.getByRole("button", { name: s.undo, exact: true }).click();
  await expect(page.getByText(s.moveUndone)).toBeVisible();
  await expect(saraWith(monaId)).toBeVisible();
  await expect(saraWith(noorId)).toHaveCount(0);

  // An hour later with Mona is free.
  await drag(page, saraWith(monaId), column(monaId), 60);
  await expect(page.getByText(s.movedTo(sara))).toBeVisible();
  await expect(timeOf(saraWith(monaId))).toHaveText(hours("16:00", "17:00"));
});

test("the keyboard reaches appointments through the skip link, moves between columns and moves a visit with Alt+arrows", async ({
  page,
  request,
  s,
  appLocale,
}) => {
  const id = unique(appLocale);
  const day = addDays(kuwaitToday(), 1);
  const sara = appLocale === "ar" ? `سارة ${id}` : `Sara ${id}`;
  const lina = appLocale === "ar" ? `لينا ${id}` : `Lina ${id}`;
  const { monaId, noorId } = await twoBooked(request, id, day);

  const byStaff = await openDay(page, s, day, [monaId, noorId]);
  const saraEvent = byStaff.locator(`.gd-resource-column[data-resource-id="${monaId}"] ${EVENT}`).filter({ hasText: sara });
  const linaEvent = byStaff.locator(`.gd-resource-column[data-resource-id="${noorId}"] ${EVENT}`).filter({ hasText: lina });
  await expect(linaEvent).toBeVisible();

  const skip = page.getByRole("button", { name: s.skipToAppointments });
  await skip.focus();
  await expect(skip).toBeVisible();
  await page.keyboard.press("Enter");
  await expect(saraEvent).toBeFocused();
  // One tab stop for the whole grid.
  await expect(byStaff.locator(`${EVENT}[tabindex="0"]`)).toHaveCount(1);

  // The next column is to the right in English and to the left in Arabic.
  await page.keyboard.press(appLocale === "ar" ? "ArrowLeft" : "ArrowRight");
  await expect(linaEvent).toBeFocused();

  await expect(timeOf(linaEvent)).toHaveText(hours("15:00", "16:00"));
  for (let step = 0; step < 4; step += 1) await page.keyboard.press("Alt+ArrowDown");
  await expect(timeOf(linaEvent)).toHaveText(hours("16:00", "17:00"));
  // Four quick moves are announced once.
  await expect(page.getByRole("status").filter({ hasText: s.movedTo(lina) })).toHaveCount(1);

  // Undo returns the visit to where the burst started.
  await page.getByRole("button", { name: s.undo, exact: true }).click();
  await expect(page.getByText(s.moveUndone)).toBeVisible();
  await expect(timeOf(linaEvent)).toHaveText(hours("15:00", "16:00"));
});

test("an owner moves an appointment to another branch: a new reference and that branch's price", async ({ page, request, s, appLocale }) => {
  const id = unique(appLocale);
  const day = addDays(kuwaitToday(), 1);
  const serviceId = await createService(request, { en: `Facial ${id}`, ar: `تنظيف بشرة ${id}` }, { duration: 60, price: 25_000 });
  const staffId = await createStaff(request, {
    name: { en: `Mona ${id}`, ar: `منى ${id}` },
    branchId: SETUP_BRANCH.hawally,
    serviceIds: [serviceId],
    shifts: [{ day, starts: "09:00", ends: "14:00" }],
  });
  // Mornings at Hawally, afternoons at Jahra: one person's shifts never overlap.
  await assignToBranch(request, staffId, { branchId: SETUP_BRANCH.jahra, serviceIds: [serviceId], shifts: [{ day, starts: "14:00", ends: "22:00" }] });
  await setBranchPrice(request, serviceId, SETUP_BRANCH.jahra, 30_000);
  const clientId = await createClient(request, { firstName: "Sara", lastName: id, firstNameAlt: "سارة", lastNameAlt: id });
  const ref = await book(request, "setup-reception@spacorner.test", {
    branchId: SETUP_BRANCH.hawally,
    clientId,
    items: [{ service_id: serviceId, staff_id: staffId, starts_at: kuwait(day, "10:00") }],
  });
  expect(ref).toMatch(/^HWL-/);

  await page.goto("/login");
  await signIn(page, s, "setup-owner@spacorner.test");
  await expect(page).toHaveURL(/\?branch=/);
  await page.goto(`/calendar?branch=${SETUP_BRANCH.hawally}&date=${day}`);
  await page.getByRole("region", { name: s.appointmentsByStaff }).locator(EVENT).filter({ hasText: id }).click();
  const drawer = page.getByRole("dialog", { name: new RegExp(id) });
  await drawer.getByRole("button", { name: s.move, exact: true }).click();

  const dialog = page.getByRole("dialog", { name: s.moveAppointment });
  await dialog.getByRole("combobox", { name: s.branch }).selectOption(SETUP_BRANCH.jahra);
  await expect(dialog.getByRole("combobox", { name: s.teamMember })).toHaveValue(staffId);
  await dialog.getByRole("radio", { name: "16:00", exact: true }).check();
  await dialog.getByRole("button", { name: s.moveAppointment }).click();

  const moved = page.getByRole("dialog", { name: s.appointmentMoved });
  await expect(moved).toBeVisible();
  await expect(moved).toContainText(/JHR-A\d+/);
  await expect(moved).toContainText("30.000");
});
