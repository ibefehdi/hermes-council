import {
  addCategory,
  categoryOrder,
  editorPanel,
  fillDefinition,
  openCatalogue,
  openCategory,
  serviceIdFromUrl,
  serviceRow,
  servicesTable,
} from "./catalogueFlows";
import { expect, signIn, test } from "./fixtures";
import { newPersonPage, unique } from "./memberFlows";
import { SETUP_BRANCH, addStaff, openStaffList } from "./staffFlows";

// Setup Studio (supabase/seed.sql) gets a fresh category, service and staff
// member each run. Definitions are the owner's; branch overrides and eligibility
// belong to whoever manages the branch (ADR-13, ADR-28).

test("the owner builds the menu; one branch opts out; the manager changes only their branch; reception reads", async ({
  page,
  browser,
  s,
  appLocale,
}) => {
  const id = unique(appLocale);
  const category = appLocale === "ar" ? `تصنيف ${id}` : `Category ${id}`;
  const service = appLocale === "ar" ? `خدمة ${id}` : `Service ${id}`;
  const therapist = appLocale === "ar" ? `نورة ${id}` : `Noura ${id}`;

  await page.goto("/login");
  await signIn(page, s, "setup-owner@spacorner.test");
  await openStaffList(page, s, SETUP_BRANCH.hawally);
  await addStaff(page, s, { nameEn: `Noura ${id}`, nameAr: `نورة ${id}`, branches: [s.hawally, s.jahra] });

  // A new category goes to the end of the menu; the owner moves it up one place.
  await openCatalogue(page, s, "all");
  await addCategory(page, s, { nameEn: `Category ${id}`, nameAr: `تصنيف ${id}` });
  await expect.poll(() => categoryOrder(page, s)).toContain(category);
  const before = await categoryOrder(page, s);
  const neighbour = before[before.indexOf(category) - 1]!;
  await page.getByRole("button", { name: s.moveUp(category) }).click();
  await expect
    .poll(async () => {
      const order = await categoryOrder(page, s);
      return order.indexOf(category) < order.indexOf(neighbour);
    })
    .toBe(true);

  // The service: names in both scripts, buffers and a three-decimal KWD price.
  await openCategory(page, s, category);
  await page.getByRole("link", { name: s.addService }).click();
  await expect(page.getByRole("heading", { level: 1, name: s.newService })).toBeVisible();
  await fillDefinition(page, s, {
    nameEn: `Service ${id}`,
    nameAr: `خدمة ${id}`,
    duration: "7",
    bufferBefore: "5",
    bufferAfter: "10",
    price: "12.500",
  });
  await page.getByRole("button", { name: s.addService }).click();
  const definition = editorPanel(page, s.definitionTab);
  await expect(definition.getByText(s.durationStep)).toBeVisible();
  await definition.getByLabel(s.durationMinutes).fill("45");

  // Offered at Hawally and Jahra, with the new therapist eligible at Hawally.
  await page.getByRole("tab", { name: s.branches }).click();
  const branches = editorPanel(page, s.branches);
  await expect(branches.getByRole("checkbox", { name: s.offeredAt(s.hawally) })).toBeChecked();
  await expect(branches.getByRole("checkbox", { name: s.offeredAt(s.jahra) })).toBeChecked();
  await page.getByRole("tab", { name: s.eligibleStaffTab }).click();
  await editorPanel(page, s.eligibleStaffTab)
    .getByRole("group", { name: s.hawally })
    .getByRole("checkbox", { name: therapist })
    .check();
  await page.getByRole("button", { name: s.addService }).click();
  await expect(page.getByText(s.serviceAdded)).toBeVisible();
  await expect(page).toHaveURL(/\/catalogue\/services\/[0-9a-f-]{36}/);
  const serviceId = serviceIdFromUrl(page);
  await expect(definition.getByLabel(s.price)).toHaveValue("12.500");
  await expect(definition.getByLabel(s.durationMinutes)).toHaveValue("45");

  // Jahra stops offering it.
  await page.getByRole("tab", { name: s.branches }).click();
  await branches.getByRole("checkbox", { name: s.offeredAt(s.jahra) }).uncheck();
  await page.getByRole("button", { name: s.saveService }).click();
  await expect(page.getByText(s.serviceSaved)).toBeVisible();

  // Hidden under Jahra (until asked for), still offered at Hawally, and flagged on the overview.
  await openCatalogue(page, s, SETUP_BRANCH.jahra);
  await openCategory(page, s, category);
  await expect(servicesTable(page, s, category).getByRole("link", { name: service })).toHaveCount(0);
  await page.getByRole("checkbox", { name: s.showOneDisabled }).check();
  await expect(serviceRow(page, s, category, service)).toContainText(s.disabledHere);
  await openCatalogue(page, s, SETUP_BRANCH.hawally);
  await openCategory(page, s, category);
  await expect(serviceRow(page, s, category, service)).toContainText(s.inheritsDefault);
  await openCatalogue(page, s, "all");
  await openCategory(page, s, category);
  await expect(serviceRow(page, s, category, service)).toContainText(s.overridesAtOne);

  // Hawally's manager: the definition is read-only and only Hawally is shown.
  const manager = await newPersonPage(browser, appLocale);
  await manager.goto("/login");
  await signIn(manager, s, "setup-manager@spacorner.test");
  await expect(manager).not.toHaveURL(/\/login/);
  await manager.goto(`/catalogue/services/${serviceId}?branch=${SETUP_BRANCH.hawally}`);
  await expect(manager.getByText(s.ownerOnlyDefinition)).toBeVisible();
  await expect(editorPanel(manager, s.definitionTab).getByLabel(s.nameEn)).toBeDisabled();
  await manager.getByRole("tab", { name: s.branches }).click();
  const managed = editorPanel(manager, s.branches);
  await expect(managed.getByRole("checkbox", { name: s.offeredAt(s.hawally) })).toBeEnabled();
  await expect(managed.getByRole("checkbox", { name: s.offeredAt(s.jahra) })).toHaveCount(0);
  await managed.getByRole("group", { name: s.hawally }).getByLabel(s.price).fill("13.000");
  await manager.getByRole("button", { name: s.saveService }).click();
  await expect(manager.getByText(s.serviceSaved)).toBeVisible();
  await openCatalogue(manager, s, SETUP_BRANCH.hawally);
  await openCategory(manager, s, category);
  await expect(serviceRow(manager, s, category, service)).toContainText(s.branchOverride);
  await manager.context().close();

  // Reception sees the service but can't change it.
  const reception = await newPersonPage(browser, appLocale);
  await reception.goto("/login");
  await signIn(reception, s, "setup-reception@spacorner.test");
  await expect(reception).not.toHaveURL(/\/login/);
  await reception.goto(`/catalogue/services/${serviceId}?branch=${SETUP_BRANCH.hawally}`);
  await expect(reception.getByText(s.catalogueReadOnly)).toBeVisible();
  await expect(reception.getByRole("button", { name: s.saveService })).toHaveCount(0);
  await reception.context().close();
});
