import type { Locator, Page } from "@playwright/test";
import { addDays } from "./blockedTimeFlows";
import { attemptCreate, book, createClient, createService, createStaff, kuwait, overridesOf, SETUP_TENANT } from "./bookingFixtures";
import { expect, signIn, test } from "./fixtures";
import { newPersonPage, unique } from "./memberFlows";
import { kuwaitToday } from "./shiftFlows";
import { SETUP_BRANCH } from "./staffFlows";
import type { Strings } from "./strings";

// Phase 5 booking journeys at Setup Studio Hawally (open 10:00–22:00, 14:00 on
// Fridays): booking from the grid, a soft-rule override by role, a walk-in
// that gets its client later, and two live sessions. Every run books its own
// visits through the bookings function.

const RECEPTION = "setup-reception@spacorner.test";
const MANAGER = "setup-manager@spacorner.test";
const MANAGER_USER_ID = "00000000-0000-4000-8000-000000000010";
const EVENT = "[data-event-id]:not([id^='time-grid-event-copy-'])";
// BookingCalendar draws 24px per slot; Hawally keeps the default 15-minute step.
const PX_PER_MINUTE = 24 / 15;
const REALTIME_BUDGET_MS = 5_000;

type Request = Parameters<typeof createService>[0];

const timeOf = (event: Locator) => event.locator(".gd-event-time");
const hours = (start: string, end: string) => new RegExp(`${start}\\s*–\\s*${end}`);
const named = (appLocale: string, en: string, ar: string, id: string) => (appLocale === "ar" ? `${ar} ${id}` : `${en} ${id}`);

/** A fresh 60-minute facial and Mona, who does it, on shift `shift` that day. */
async function facialWithMona(request: Request, id: string, day: string, shift = { starts: "09:00", ends: "22:00" }) {
  const serviceId = await createService(request, { en: `Facial ${id}`, ar: `تنظيف بشرة ${id}` }, { duration: 60, price: 25_000 });
  const monaId = await createStaff(request, {
    name: { en: `Mona ${id}`, ar: `منى ${id}` },
    branchId: SETUP_BRANCH.hawally,
    serviceIds: [serviceId],
    shifts: [{ day, ...shift }],
  });
  return { serviceId, monaId };
}

async function signInTo(page: Page, s: Strings, email: string) {
  await page.goto("/login");
  await signIn(page, s, email);
  await expect(page).toHaveURL(/\?branch=/);
}

/** Drops this tab's session only: signing out revokes that login's sessions in parallel workers too. */
async function dropSession(page: Page) {
  await page.evaluate(() => {
    for (const key of Object.keys(window.localStorage)) if (key.startsWith("sb-")) window.localStorage.removeItem(key);
  });
}

/** Resolves once Realtime confirms the page's Hawally appointments subscription; call before navigating. */
function appointmentsLive(page: Page): Promise<void> {
  const topic = `"realtime:appointments:${SETUP_TENANT}:${SETUP_BRANCH.hawally}"`;
  return new Promise((resolve) => {
    page.on("websocket", (socket) => {
      socket.on("framereceived", ({ payload }) => {
        const frame = typeof payload === "string" ? payload : payload.toString();
        if (frame.includes(topic) && frame.includes('"Subscribed to PostgreSQL"') && frame.includes('"status":"ok"')) resolve();
      });
    });
  });
}

async function openDay(page: Page, s: Strings, day: string, staff: string[]) {
  await page.goto(`/calendar?branch=${SETUP_BRANCH.hawally}&date=${day}&staff=${encodeURIComponent(JSON.stringify(staff))}`);
  return page.getByRole("region", { name: s.appointmentsByStaff });
}

const columnOf = (byStaff: Locator, staffId: string) => byStaff.locator(`.gd-resource-column[data-resource-id="${staffId}"]`);

async function box(locator: Locator) {
  const found = await locator.boundingBox();
  if (!found) throw new Error("not on screen");
  return found;
}

/** Fills the new-booking drawer for one service with a typed start time. */
async function fillBooking(drawer: Locator, s: Strings, booking: { client: string; service: string; staff: string; time: string }) {
  await drawer.getByLabel(s.findClient).fill(booking.client);
  await drawer.getByRole("button", { name: new RegExp(booking.client) }).click();
  const item = drawer.getByRole("region", { name: s.service, exact: true });
  await item.getByRole("combobox", { name: s.service, exact: true }).selectOption({ label: booking.service });
  await item.getByRole("combobox", { name: s.teamMember }).selectOption({ label: booking.staff });
  await item.getByLabel(s.startTime).fill(booking.time);
}

test("the front desk books from an empty time on the grid: the drawer starts with that person and time", async ({
  page,
  request,
  s,
  appLocale,
}) => {
  const id = unique(appLocale);
  const day = addDays(kuwaitToday(), 1);
  const { serviceId, monaId } = await facialWithMona(request, id, day);
  const linaId = await createClient(request, { firstName: "Lina", lastName: id, firstNameAlt: "لينا", lastNameAlt: id });
  await createClient(request, { firstName: "Sara", lastName: id, firstNameAlt: "سارة", lastNameAlt: id });
  // Lina at 15:00 pins the grid's scale to a known time.
  await book(request, RECEPTION, {
    branchId: SETUP_BRANCH.hawally,
    clientId: linaId,
    items: [{ service_id: serviceId, staff_id: monaId, starts_at: kuwait(day, "15:00") }],
  });

  await signInTo(page, s, RECEPTION);
  const column = columnOf(await openDay(page, s, day, [monaId]), monaId);
  const lina = column.locator(EVENT).filter({ hasText: named(appLocale, "Lina", "لينا", id) });
  await expect(lina).toBeVisible();

  // Two hours below Lina's start is 17:00 in Mona's column.
  await lina.scrollIntoViewIfNeeded();
  const [linaBox, columnBox] = [await box(lina), await box(column)];
  await column.click({ position: { x: columnBox.width / 2, y: linaBox.y - columnBox.y + 120 * PX_PER_MINUTE + 4 } });

  const drawer = page.getByRole("dialog", { name: s.newAppointment });
  const item = drawer.getByRole("region", { name: s.service, exact: true });
  await expect(item.getByRole("combobox", { name: s.teamMember })).toHaveValue(monaId);
  await expect(item.getByLabel(s.startTime)).toHaveValue("17:00");

  await drawer.getByLabel(s.findClient).fill(`Sara ${id}`);
  await drawer.getByRole("button", { name: new RegExp(`Sara ${id}`) }).click();
  await item.getByRole("combobox", { name: s.service, exact: true }).selectOption({ label: named(appLocale, "Facial", "تنظيف بشرة", id) });
  await expect(item.getByRole("combobox", { name: s.teamMember })).toHaveValue(monaId);
  await drawer.getByRole("button", { name: s.bookAppointment }).click();

  await expect(page.getByText(s.appointmentBooked)).toBeVisible();
  await expect(drawer).toBeHidden();
  const sara = column.locator(EVENT).filter({ hasText: named(appLocale, "Sara", "سارة", id) });
  await expect(timeOf(sara)).toHaveText(hours("17:00", "18:00"));
});

test("outside a shift the front desk is sent to a manager and the function refuses its override; the manager books it and the reason is recorded", async ({
  page,
  request,
  s,
  appLocale,
}) => {
  const id = unique(appLocale);
  const day = addDays(kuwaitToday(), 1);
  // Mona works 15:00–17:00; 18:00 is inside opening hours but outside her shift.
  const { serviceId, monaId } = await facialWithMona(request, id, day, { starts: "15:00", ends: "17:00" });
  const saraId = await createClient(request, { firstName: "Sara", lastName: id, firstNameAlt: "سارة", lastNameAlt: id });
  const booking = {
    client: `Sara ${id}`,
    service: named(appLocale, "Facial", "تنظيف بشرة", id),
    staff: named(appLocale, "Mona", "منى", id),
    time: "18:00",
  };

  await signInTo(page, s, RECEPTION);
  let byStaff = await openDay(page, s, day, [monaId]);
  await page.getByRole("button", { name: s.newAppointment, exact: true }).click();
  let drawer = page.getByRole("dialog", { name: s.newAppointment });
  await fillBooking(drawer, s, booking);
  await drawer.getByRole("button", { name: s.bookAppointment }).click();
  const ask = page.getByRole("alertdialog", { name: s.askManager });
  await expect(ask).toContainText(s.outsideShift);
  await expect(ask).toContainText(s.onlyManagerConfirms);
  await expect(ask.getByRole("button", { name: s.bookAnyway })).toHaveCount(0);

  // Sending the override anyway: the function refuses it for a receptionist (5.1 ruling).
  const refused = await attemptCreate(request, RECEPTION, {
    branchId: SETUP_BRANCH.hawally,
    clientId: saraId,
    items: [{ service_id: serviceId, staff_id: monaId, starts_at: kuwait(day, "18:00") }],
    overrides: ["outside_shift"],
  });
  expect(refused.status).toBe(403);
  expect(refused.body).toMatchObject({ ok: false, error: { code: "FORBIDDEN", details: { reason: "override_forbidden" } } });
  await expect(columnOf(byStaff, monaId).locator(EVENT)).toHaveCount(0);

  await dropSession(page);
  await signInTo(page, s, MANAGER);
  byStaff = await openDay(page, s, day, [monaId]);
  await page.getByRole("button", { name: s.newAppointment, exact: true }).click();
  drawer = page.getByRole("dialog", { name: s.newAppointment });
  await fillBooking(drawer, s, booking);
  await drawer.getByRole("button", { name: s.bookAppointment }).click();
  const confirm = page.getByRole("alertdialog", { name: s.bookOutsideRules });
  await expect(confirm).toContainText(s.outsideShift);
  const reason = "Her only free hour this week";
  await confirm.getByRole("textbox", { name: s.reason }).fill(reason);
  await confirm.getByRole("button", { name: s.bookAnyway }).click();

  const booked = page.getByText(s.appointmentBooked);
  await expect(booked).toBeVisible();
  const ref = (await booked.textContent())?.match(/HWL-A\d+/)?.[0];
  expect(ref).toBeTruthy();
  await expect(timeOf(columnOf(byStaff, monaId).locator(EVENT))).toHaveText(hours("18:00", "19:00"));
  expect(await overridesOf(request, ref ?? "")).toEqual([{ rule: "outside_shift", action: "book", reason, created_by: MANAGER_USER_ID }]);
});

test("a walk-in gets its client afterwards; a blocked client is refused with the reason shown", async ({ page, request, s, appLocale }) => {
  const id = unique(appLocale);
  const day = addDays(kuwaitToday(), 1);
  const { serviceId, monaId } = await facialWithMona(request, id, day);
  await createClient(request, { firstName: "Sara", lastName: id, firstNameAlt: "سارة", lastNameAlt: id });
  await createClient(request, { firstName: "Noura", lastName: id, firstNameAlt: "نورة", lastNameAlt: id, blockedReason: "Unpaid" });
  await book(request, RECEPTION, {
    branchId: SETUP_BRANCH.hawally,
    clientId: null,
    items: [{ service_id: serviceId, staff_id: monaId, starts_at: kuwait(day, "15:00") }],
  });

  await signInTo(page, s, RECEPTION);
  const column = columnOf(await openDay(page, s, day, [monaId]), monaId);
  await column.locator(EVENT).filter({ hasText: s.walkIn }).click();
  const drawer = page.getByRole("dialog", { name: s.walkIn });
  await expect(drawer).toContainText(s.walkInNoRecord);
  await drawer.getByRole("button", { name: s.attachAClient }).click();

  const dialog = page.getByRole("dialog", { name: s.attachAClient });
  // Result buttons carry both names, so the Latin one matches in either language.
  await dialog.getByLabel(s.findClient).fill(`Noura ${id}`);
  await dialog.getByRole("button", { name: new RegExp(`Noura ${id}`) }).click();
  await dialog.getByRole("button", { name: s.attachClient }).click();
  await expect(dialog.getByRole("alert").filter({ hasText: s.clientBlockedFromBooking })).toBeVisible();

  await dialog.getByRole("button", { name: s.changeClient }).click();
  await dialog.getByLabel(s.findClient).fill(`Sara ${id}`);
  await dialog.getByRole("button", { name: new RegExp(`Sara ${id}`) }).click();
  await dialog.getByRole("button", { name: s.attachClient }).click();
  await expect(page.getByText(s.clientAttached)).toBeVisible();
  await expect(dialog).toBeHidden();

  const sara = named(appLocale, "Sara", "سارة", id);
  await expect(page.getByRole("dialog", { name: sara })).toBeVisible();
  await expect(column.locator(EVENT).filter({ hasText: sara })).toHaveCount(1);
  await expect(column.locator(EVENT).filter({ hasText: s.walkIn })).toHaveCount(0);
});

test("two sessions see each other's changes within 5 seconds", async ({ page, browser, request, s, appLocale }) => {
  const id = unique(appLocale);
  const day = addDays(kuwaitToday(), 1);
  const { serviceId, monaId } = await facialWithMona(request, id, day);
  const noorId = await createStaff(request, {
    name: { en: `Noor ${id}`, ar: `نور ${id}` },
    branchId: SETUP_BRANCH.hawally,
    serviceIds: [serviceId],
    shifts: [{ day, starts: "09:00", ends: "22:00" }],
  });
  const saraId = await createClient(request, { firstName: "Sara", lastName: id, firstNameAlt: "سارة", lastNameAlt: id });
  const linaId = await createClient(request, { firstName: "Lina", lastName: id, firstNameAlt: "لينا", lastNameAlt: id });
  for (const [clientId, staffId] of [
    [saraId, monaId],
    [linaId, noorId],
  ] as const) {
    await book(request, RECEPTION, {
      branchId: SETUP_BRANCH.hawally,
      clientId,
      items: [{ service_id: serviceId, staff_id: staffId, starts_at: kuwait(day, "15:00") }],
    });
  }
  const sara = named(appLocale, "Sara", "سارة", id);
  const lina = named(appLocale, "Lina", "لينا", id);
  const staff = [monaId, noorId];

  // Both grids are live (subscribed) before either session changes anything.
  await signInTo(page, s, RECEPTION);
  const deskLive = appointmentsLive(page);
  const desk = await openDay(page, s, day, staff);
  const manager = await newPersonPage(browser, appLocale);
  await signInTo(manager, s, MANAGER);
  const officeLive = appointmentsLive(manager);
  const office = await openDay(manager, s, day, staff);
  await Promise.all([deskLive, officeLive]);
  const saraOn = (grid: Locator) => columnOf(grid, monaId).locator(EVENT).filter({ hasText: sara });
  const linaOn = (grid: Locator) => columnOf(grid, noorId).locator(EVENT).filter({ hasText: lina });
  await expect(saraOn(office)).toBeVisible();
  await expect(linaOn(desk)).toBeVisible();

  // The desk moves Sara an hour later from the keyboard; the manager's grid follows.
  await page.getByRole("button", { name: s.skipToAppointments }).focus();
  await page.keyboard.press("Enter");
  await expect(saraOn(desk)).toBeFocused();
  let started = Date.now();
  for (let step = 0; step < 4; step += 1) await page.keyboard.press("Alt+ArrowDown");
  await expect(timeOf(saraOn(office))).toHaveText(hours("16:00", "17:00"), { timeout: REALTIME_BUDGET_MS });
  test.info().annotations.push({ type: "realtime", description: `move seen by the other session ${Date.now() - started} ms after the first key` });
  await expect(page.getByRole("status").filter({ hasText: s.movedTo(sara) })).toHaveCount(1);

  // The manager cancels Lina; she leaves the desk's grid.
  await linaOn(office).click();
  const drawer = manager.getByRole("dialog", { name: new RegExp(id) });
  await drawer.getByRole("button", { name: s.cancelAppointment }).click();
  const cancel = manager.getByRole("dialog", { name: s.cancelThisAppointment });
  await cancel.getByRole("combobox", { name: s.reason }).selectOption({ label: s.clientUnwell });
  started = Date.now();
  await cancel.getByRole("button", { name: s.cancelAppointment }).click();
  await expect(linaOn(desk)).toHaveCount(0, { timeout: REALTIME_BUDGET_MS });
  test.info().annotations.push({ type: "realtime", description: `cancel seen by the other session ${Date.now() - started} ms after the click` });
  await expect(manager.getByText(s.appointmentCancelled)).toBeVisible();

  await manager.context().close();
});
