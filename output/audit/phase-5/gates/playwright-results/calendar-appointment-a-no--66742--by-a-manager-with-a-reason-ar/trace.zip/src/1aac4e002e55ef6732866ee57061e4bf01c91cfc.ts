import type { Page } from "@playwright/test";
import { addDays } from "./blockedTimeFlows";
import { book, createClient, createService, createStaff, kuwait } from "./bookingFixtures";
import { expect, signIn, test } from "./fixtures";
import { unique } from "./memberFlows";
import { kuwaitToday } from "./shiftFlows";
import { SETUP_BRANCH } from "./staffFlows";
import type { Strings } from "./strings";

// The appointment drawer at Setup Studio Hawally: each run books a fresh
// appointment through the bookings function, then works it from the calendar.

async function bookOne(request: Parameters<typeof createService>[0], id: string, day: string) {
  const serviceId = await createService(request, { en: `Facial ${id}`, ar: `تنظيف بشرة ${id}` }, { duration: 60, price: 25_000 });
  const staffId = await createStaff(request, {
    name: { en: `Mona ${id}`, ar: `منى ${id}` },
    branchId: SETUP_BRANCH.hawally,
    serviceIds: [serviceId],
    shifts: [{ day, starts: "09:00", ends: "22:00" }],
  });
  const clientId = await createClient(request, { firstName: "Sara", lastName: id, firstNameAlt: "سارة", lastNameAlt: id });
  await book(request, "setup-reception@spacorner.test", {
    branchId: SETUP_BRANCH.hawally,
    clientId,
    items: [{ service_id: serviceId, staff_id: staffId, starts_at: kuwait(day, "15:00") }],
  });
}

async function openAppointment(page: Page, s: Strings, email: string, id: string, day: string) {
  await page.goto("/login");
  await signIn(page, s, email);
  await expect(page).toHaveURL(/\?branch=/);
  await page.goto(`/calendar?branch=${SETUP_BRANCH.hawally}&date=${day}`);
  const byStaff = page.getByRole("region", { name: s.appointmentsByStaff });
  await byStaff.locator("[data-event-id]:not([id^='time-grid-event-copy-'])").filter({ hasText: id }).click();
  return page.getByRole("dialog", { name: new RegExp(id) });
}

const events = (page: Page, s: Strings, id: string) =>
  page.getByRole("region", { name: s.appointmentsByStaff }).locator("[data-event-id]").filter({ hasText: id });

test("the front desk confirms an appointment, then cancels it with a reason and the time frees up", async ({ page, request, s, appLocale }) => {
  const id = unique(appLocale);
  const day = addDays(kuwaitToday(), 1);
  await bookOne(request, id, day);

  const drawer = await openAppointment(page, s, "setup-reception@spacorner.test", id, day);
  await expect(drawer).toContainText("25.000");
  await drawer.getByRole("button", { name: s.confirm, exact: true }).click();
  await expect(page.getByText(s.statusChangedTo(s.confirmed))).toBeVisible();
  await expect(drawer.getByText(s.confirmed, { exact: true })).toBeVisible();

  await drawer.getByRole("button", { name: s.cancelAppointment }).click();
  const dialog = page.getByRole("dialog", { name: s.cancelThisAppointment });
  // Escape closes only the dialog on top; the drawer stays.
  await expect(dialog).toBeVisible();
  await page.keyboard.press("Escape");
  await expect(dialog).toBeHidden();
  await expect(drawer).toBeVisible();
  await drawer.getByRole("button", { name: s.cancelAppointment }).click();
  // The reason is required: submitting without one says so.
  await dialog.getByRole("button", { name: s.cancelAppointment }).click();
  await expect(dialog.getByRole("alert")).toBeVisible();
  await dialog.getByRole("combobox", { name: s.reason }).selectOption({ label: s.clientUnwell });
  await dialog.getByRole("button", { name: s.cancelAppointment }).click();

  await expect(page.getByText(s.appointmentCancelled)).toBeVisible();
  await expect(dialog).toBeHidden();
  await expect(drawer).toContainText(s.cancelledBecause(s.clientUnwell));
  await expect(events(page, s, id)).toHaveCount(0);
});

test("a no-show is recorded by the front desk and reopened by a manager with a reason", async ({ page, request, s, appLocale }) => {
  const id = unique(appLocale);
  const day = addDays(kuwaitToday(), 1);
  await bookOne(request, id, day);

  const drawer = await openAppointment(page, s, "setup-reception@spacorner.test", id, day);
  await drawer.getByRole("button", { name: s.noShow, exact: true }).click();
  await page.getByRole("alertdialog").getByRole("button", { name: s.markNoShow }).click();
  await expect(page.getByText(s.statusChangedTo(s.noShow))).toBeVisible();
  // The receptionist can't reopen it (5.1 ruling: backward moves are for managers).
  await expect(drawer.getByRole("button", { name: s.reopen })).toHaveCount(0);
  await expect(events(page, s, id)).toHaveCount(1);
  await page.keyboard.press("Escape");
  await expect(drawer).toBeHidden();
  // Drop this tab's session only: signing out revokes the receptionist's sessions in parallel workers too.
  await page.evaluate(() => {
    for (const key of Object.keys(window.localStorage)) if (key.startsWith("sb-")) window.localStorage.removeItem(key);
  });

  const managerDrawer = await openAppointment(page, s, "setup-manager@spacorner.test", id, day);
  await managerDrawer.getByRole("button", { name: s.reopen }).click();
  const dialog = page.getByRole("dialog", { name: new RegExp(s.reopen) });
  // A reason is required for a backward move.
  await dialog.getByRole("button", { name: s.reopen, exact: true }).click();
  const reason = dialog.getByRole("textbox", { name: s.reason });
  await expect(reason).toHaveAttribute("aria-invalid", "true");
  await reason.fill("Arrived late, still served");
  await dialog.getByRole("button", { name: s.reopen, exact: true }).click();
  await expect(page.getByText(s.statusChangedTo(s.booked))).toBeVisible();
  await expect(managerDrawer.getByText(s.booked, { exact: true })).toBeVisible();
});
