import type { Page } from "@playwright/test";
import { expect } from "./fixtures";
import type { Strings } from "./strings";

// Staff journeys shared by staff.spec.ts and the Phase 2 evidence run.

export const SETUP_BRANCH = {
  hawally: "00000000-0000-4000-a000-000000000004",
  jahra: "00000000-0000-4000-a000-000000000005",
} as const;

export async function openStaffList(page: Page, s: Strings, branchId?: string) {
  if (branchId) {
    // A just-submitted sign-in must land before a full page load.
    await expect(page).not.toHaveURL(/\/login/);
    await page.goto(`/team/staff?branch=${branchId}`);
  } else {
    await page.getByRole("link", { name: s.team, exact: true }).click();
  }
  await expect(page.getByRole("heading", { level: 1, name: s.teamMembers })).toBeVisible();
}

export type NewStaff = {
  nameEn: string;
  nameAr: string;
  email?: string;
  /** Branch labels to tick; the active branch starts ticked. */
  branches: string[];
  defaultBranch?: string;
};

/** Fills the new-staff form from the list page and saves; ends on the new staff member's editor. */
export async function addStaff(page: Page, s: Strings, staff: NewStaff) {
  await page.getByRole("link", { name: s.addStaffMember }).click();
  await expect(page.getByRole("heading", { level: 1, name: s.addStaffMember })).toBeVisible();
  await page.getByLabel(s.fullNameEn).fill(staff.nameEn);
  await page.getByLabel(s.fullNameAr).fill(staff.nameAr);
  if (staff.email) await page.getByLabel(s.email).fill(staff.email);
  for (const branch of staff.branches) {
    await page.getByRole("checkbox", { name: branch, exact: true }).check();
  }
  if (staff.defaultBranch) await page.getByLabel(s.defaultBranch).selectOption({ label: staff.defaultBranch });
  await page.getByRole("button", { name: s.addStaffMember }).click();
  await expect(page.getByText(s.staffAdded)).toBeVisible();
  await expect(page).toHaveURL(/\/team\/staff\/[0-9a-f-]{36}/);
}

export const staffRow = (page: Page, marker: string) => page.getByRole("row", { name: new RegExp(marker) });
