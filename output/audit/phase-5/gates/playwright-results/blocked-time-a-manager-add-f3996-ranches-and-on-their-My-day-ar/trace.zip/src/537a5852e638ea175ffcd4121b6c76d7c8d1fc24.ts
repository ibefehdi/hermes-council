import {
  addDays,
  blockTable,
  blockTime,
  editBlockButtons,
  fillTimes,
  freshDay,
  openBlockedTime,
  seedAppointment,
  staffIdFromUrl,
} from "./blockedTimeFlows";
import { expect, signIn, test } from "./fixtures";
import { acceptInvite, newPersonPage, unique } from "./memberFlows";
import { kuwaitToday } from "./shiftFlows";
import { SETUP_BRANCH, addStaff, openStaffList } from "./staffFlows";

// Setup Studio (supabase/seed.sql) gets fresh staff and far-future dates each
// run. Hawally is Asia/Kuwait; every write goes through the locked RPCs.

test("a receptionist blocks time at their branch; overlaps and appointments are explained; the block moves and goes", async ({
  page,
  browser,
  request,
  s,
  appLocale,
}) => {
  const id = unique(appLocale);
  const day = freshDay();
  const name = appLocale === "ar" ? `حجب ${id}` : `Block ${id}`;

  await page.goto("/login");
  await signIn(page, s, "setup-manager@spacorner.test");
  await openStaffList(page, s, SETUP_BRANCH.hawally);
  await addStaff(page, s, { nameEn: `Block ${id}`, nameAr: `حجب ${id}`, branches: [s.hawally] });
  const staffId = staffIdFromUrl(page);
  await seedAppointment(request, { staffId, branchId: SETUP_BRANCH.hawally, day, start: "15:00", end: "16:00" });

  const reception = await newPersonPage(browser, appLocale);
  await reception.goto("/login");
  await signIn(reception, s, "setup-reception@spacorner.test");
  await openBlockedTime(reception, s, SETUP_BRANCH.hawally, { from: day, to: day });
  await expect(reception.getByText(s.noBlocks)).toBeVisible();

  // Own-branch block, typed; a receptionist never gets the every-branch option.
  await reception.getByRole("button", { name: s.blockTime, exact: true }).click();
  await expect(reception.getByRole("dialog").getByRole("checkbox", { name: s.timeOffEverywhere })).toHaveCount(0);
  await reception.getByRole("dialog").getByRole("button", { name: s.close }).click();
  await blockTime(reception, s, { staff: name, type: s.breakType, timed: { day, starts: "13:00", ends: "14:00" } });
  await expect(reception.getByText(s.timeBlocked)).toBeVisible();
  const table = blockTable(reception, s);
  await expect(table.getByRole("row", { name: new RegExp(id) })).toContainText(s.breakType);
  await expect(table.getByRole("row", { name: new RegExp(id) })).toContainText(s.thisBranch);

  // The same person can't be blocked twice at once, nor over an appointment.
  await blockTime(reception, s, { staff: name, type: s.breakType, timed: { day, starts: "13:30", ends: "14:30" } });
  await expect(reception.getByRole("dialog").getByText(s.blockOverlap)).toBeVisible();
  await fillTimes(reception, s, { starts: "15:30", ends: "16:30" });
  await reception.getByRole("dialog").getByRole("button", { name: s.blockTime, exact: true }).click();
  await expect(reception.getByRole("dialog").getByText(s.blockAppointment)).toBeVisible();
  await reception.getByRole("dialog").getByRole("button", { name: s.close }).click();

  // Move: stretching over its own time is fine; onto the appointment is not.
  await editBlockButtons(reception, s, name).click();
  await fillTimes(reception, s, { starts: "13:00", ends: "15:30" });
  await reception.getByRole("dialog").getByRole("button", { name: s.saveBlock }).click();
  await expect(reception.getByRole("dialog").getByText(s.blockAppointment)).toBeVisible();
  await fillTimes(reception, s, { starts: "12:30", ends: "14:30" });
  await reception.getByRole("dialog").getByRole("button", { name: s.saveBlock }).click();
  await expect(reception.getByText(s.blockSaved)).toBeVisible();

  // Delete asks first.
  await editBlockButtons(reception, s, name).click();
  await reception.getByRole("dialog").getByRole("button", { name: s.deleteBlock }).click();
  await reception.getByRole("alertdialog").getByRole("button", { name: s.deleteBlock }).click();
  await expect(reception.getByText(s.blockDeleted)).toBeVisible();
  await expect(reception.getByText(s.noBlocks)).toBeVisible();
  await reception.context().close();
});

test("a manager adds time off at every branch on a person's behalf; it shows at both branches and on their My day", async ({
  page,
  browser,
  request,
  s,
  appLocale,
}) => {
  const id = unique(appLocale);
  const email = `block-${id}@spacorner.test`;
  const name = appLocale === "ar" ? `سارة ${id}` : `Sara ${id}`;
  const first = addDays(kuwaitToday(), 1);
  const last = addDays(kuwaitToday(), 2);

  // The owner adds someone who works at both branches and invites them.
  await page.goto("/login");
  await signIn(page, s, "setup-owner@spacorner.test");
  await openStaffList(page, s, SETUP_BRANCH.hawally);
  await addStaff(page, s, { nameEn: `Sara ${id}`, nameAr: `سارة ${id}`, email, branches: [s.hawally, s.jahra] });
  await page.getByRole("button", { name: s.inviteToSignIn }).click();
  await expect(page.getByText(s.invitationSentTo(email))).toBeVisible();

  // Hawally's manager books two days off for them, everywhere.
  const manager = await newPersonPage(browser, appLocale);
  await manager.goto("/login");
  await signIn(manager, s, "setup-manager@spacorner.test");
  await openBlockedTime(manager, s, SETUP_BRANCH.hawally);
  await blockTime(manager, s, { staff: name, type: s.personalType, everywhere: true, allDay: { first, last } });
  await expect(manager.getByText(s.timeBlocked)).toBeVisible();
  const row = blockTable(manager, s).getByRole("row", { name: new RegExp(id) });
  await expect(row).toContainText(s.personalType);
  await expect(row).toContainText(s.everyBranch);
  await manager.context().close();

  // The owner sees the same time off from Jahra.
  await openBlockedTime(page, s, SETUP_BRANCH.jahra);
  await expect(blockTable(page, s).getByRole("row", { name: new RegExp(id) })).toContainText(s.everyBranch);

  // The person sees it on their own schedule, read-only: no request or approval step (ADR-53).
  const person = await newPersonPage(browser, appLocale);
  await acceptInvite(person, request, s, email, `Glow-${id}`);
  await person.getByRole("link", { name: s.myDay }).click();
  const mine = person.getByRole("table", { name: s.yourBlockedTime });
  await expect(mine).toContainText(s.personalType);
  await expect(mine).toContainText(s.everyBranch);
  await expect(mine.getByRole("button")).toHaveCount(0);
  await person.context().close();
});
