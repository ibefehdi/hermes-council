import { test as base, expect, type Page } from "@playwright/test";
import { strings, type AppLocale, type Strings } from "./strings";

export type AppLocaleOptions = { appLocale: AppLocale };

type Fixtures = {
  /** UI strings of the project's language. */
  s: Strings;
  /** UI strings of the other language (after switching). */
  other: Strings;
};

export const test = base.extend<Fixtures & AppLocaleOptions>({
  appLocale: ["en", { option: true }],
  page: async ({ page, appLocale }, use) => {
    // Starts the device in the project language; a later in-app switch still wins.
    await page.addInitScript((locale) => {
      if (window.localStorage.getItem("glowdesk.locale") === null) {
        window.localStorage.setItem("glowdesk.locale", locale);
      }
    }, appLocale);
    await use(page);
  },
  s: async ({ appLocale }, use) => {
    await use(strings[appLocale]);
  },
  other: async ({ appLocale }, use) => {
    await use(strings[appLocale === "en" ? "ar" : "en"]);
  },
});

export { expect };

export const PASSWORD = "password123";

export async function expectDocumentLocale(page: Page, s: Strings) {
  await expect(page.locator("html")).toHaveAttribute("lang", s.lang);
  await expect(page.locator("html")).toHaveAttribute("dir", s.dir);
}

export async function signIn(page: Page, s: Strings, email: string, password = PASSWORD) {
  const emailField = page.getByLabel(s.email);
  const passwordField = page.getByLabel(s.password, { exact: true });
  await emailField.fill(email);
  await passwordField.fill(password);
  await expect(emailField).toHaveValue(email);
  await expect(passwordField).toHaveValue(password);
  await page.getByRole("button", { name: s.signIn }).click();
}

/** Opens the topbar account menu (theme switcher, sign out) if it is closed. */
export async function openAccountMenu(page: Page) {
  const trigger = page.getByRole("banner").locator('button[aria-haspopup="dialog"]');
  if ((await trigger.getAttribute("aria-expanded")) !== "true") await trigger.click();
}

export async function signOut(page: Page, s: Strings) {
  // Inside the shell, sign out lives in the account menu; standalone pages show it directly.
  if ((await page.getByRole("banner").locator('button[aria-haspopup="dialog"]').count()) > 0) {
    await openAccountMenu(page);
  }
  await page.getByRole("button", { name: s.signOut }).click();
  await expect(page).toHaveURL(/\/login/);
}
