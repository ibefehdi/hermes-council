import type { APIRequestContext } from "@playwright/test";
import { functionUrl } from "@repo/api";
import { expect, PASSWORD } from "./fixtures";

// Phase 5 booking fixtures. Each run provisions its own Setup Studio staff,
// services, clients and shifts with the local service key (never touching the
// SpaCorner seed), then books through the bookings function as a front-desk
// login, never by writing appointments directly. `pnpm db:reset` clears them.

const API = "http://127.0.0.1:54321";
const REST = `${API}/rest/v1`;
// The local stack's well-known keys (supabase/functions/_shared/testing.ts).
const ANON_KEY =
  "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZS1kZW1vIiwicm9sZSI6ImFub24iLCJleHAiOjE5ODM4MTI5OTZ9.CRXP1A7WOeoJeXxjNni43kdQwgnWNReilDMblYTn_I0";
const SERVICE_KEY =
  "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZS1kZW1vIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImV4cCI6MTk4MzgxMjk5Nn0.EGIM96RAZx35lJzdJsyH-qQwv8Hdp7fsn3W0YpN81IU";

export const SETUP_TENANT = "00000000-0000-4000-9000-000000000003";
const admin = { apikey: SERVICE_KEY, authorization: `Bearer ${SERVICE_KEY}`, prefer: "return=representation" };

async function insert<T = { id: string }>(request: APIRequestContext, table: string, data: unknown): Promise<T[]> {
  const response = await request.post(`${REST}/${table}`, { headers: admin, data });
  expect(response.ok(), `${table}: ${await response.text()}`).toBe(true);
  return (await response.json()) as T[];
}

async function insertOne(request: APIRequestContext, table: string, data: unknown): Promise<string> {
  const [row] = await insert(request, table, data);
  if (!row) throw new Error(`no ${table} row returned`);
  return row.id;
}

/** A Kuwait wall-clock time on `day` as an instant with its offset. */
export const kuwait = (day: string, time: string) => `${day}T${time}:00+03:00`;

const FIXTURE_CATEGORY = "Booking fixtures";
let fixtureCategory: Promise<string> | null = null;

/**
 * The one category every fixture service shares. Categories append to the menu, so creating them
 * while catalogue.spec reorders its own breaks that test; global setup creates it before any worker.
 */
export async function ensureFixtureCategory(request: APIRequestContext): Promise<string> {
  const found = await request.get(
    `${REST}/service_categories?tenant_id=eq.${SETUP_TENANT}&name_en=eq.${encodeURIComponent(FIXTURE_CATEGORY)}&select=id&order=created_at&limit=1`,
    { headers: admin },
  );
  expect(found.ok(), await found.text()).toBe(true);
  const [row] = (await found.json()) as { id: string }[];
  return row?.id ?? insertOne(request, "service_categories", { tenant_id: SETUP_TENANT, name_en: FIXTURE_CATEGORY });
}

function fixtureCategoryId(request: APIRequestContext): Promise<string> {
  fixtureCategory ??= ensureFixtureCategory(request);
  return fixtureCategory;
}

export async function createService(
  request: APIRequestContext,
  name: { en: string; ar: string },
  opts: { duration?: number; price?: number } = {},
): Promise<string> {
  const categoryId = await fixtureCategoryId(request);
  return insertOne(request, "services", {
    tenant_id: SETUP_TENANT,
    category_id: categoryId,
    name_en: name.en,
    name_ar: name.ar,
    duration_minutes: opts.duration ?? 60,
    price_minor: opts.price ?? 5000,
  });
}

export type StaffSpec = {
  name: { en: string; ar: string };
  branchId: string;
  serviceIds: string[];
  /** One shift per entry, Kuwait wall-clock. */
  shifts: { day: string; starts: string; ends: string }[];
  /** A staff-role login with the seed password. */
  email?: string;
};

/** A bookable staff member at one branch, eligible for `serviceIds`, with shifts and optionally a login. */
export async function createStaff(request: APIRequestContext, spec: StaffSpec): Promise<string> {
  let userId: string | null = null;
  if (spec.email) {
    const created = await request.post(`${API}/auth/v1/admin/users`, {
      headers: admin,
      data: { email: spec.email, password: PASSWORD, email_confirm: true },
    });
    expect(created.ok(), await created.text()).toBe(true);
    userId = ((await created.json()) as { id: string }).id;
    await insert(request, "memberships", { tenant_id: SETUP_TENANT, user_id: userId, role: "staff", branch_id: spec.branchId });
  }
  const staffId = await insertOne(request, "staff_members", {
    tenant_id: SETUP_TENANT,
    full_name_en: spec.name.en,
    full_name_ar: spec.name.ar,
    user_id: userId,
  });
  await insert(request, "staff_branch_assignments", { tenant_id: SETUP_TENANT, staff_id: staffId, branch_id: spec.branchId, is_default: true });
  await makeBookable(request, staffId, spec);
  return staffId;
}

/** Makes an existing staff member (already assigned to the branch) eligible for `serviceIds` and gives them shifts. */
export async function makeBookable(
  request: APIRequestContext,
  staffId: string,
  spec: Pick<StaffSpec, "branchId" | "serviceIds" | "shifts">,
): Promise<void> {
  if (spec.serviceIds.length > 0) {
    await insert(
      request,
      "service_staff",
      spec.serviceIds.map((serviceId) => ({ tenant_id: SETUP_TENANT, service_id: serviceId, branch_id: spec.branchId, staff_id: staffId })),
    );
  }
  if (spec.shifts.length > 0) {
    await insert(
      request,
      "shifts",
      spec.shifts.map((shift) => ({
        tenant_id: SETUP_TENANT,
        staff_id: staffId,
        branch_id: spec.branchId,
        starts_at: kuwait(shift.day, shift.starts),
        ends_at: kuwait(shift.day, shift.ends),
      })),
    );
  }
}

/** Assigns an existing staff member to a second branch and makes them bookable there. */
export async function assignToBranch(
  request: APIRequestContext,
  staffId: string,
  spec: Pick<StaffSpec, "branchId" | "serviceIds" | "shifts">,
): Promise<void> {
  await insert(request, "staff_branch_assignments", { tenant_id: SETUP_TENANT, staff_id: staffId, branch_id: spec.branchId, is_default: false });
  await makeBookable(request, staffId, spec);
}

/** A branch price for a service (`service_branch_overrides`). */
export async function setBranchPrice(request: APIRequestContext, serviceId: string, branchId: string, price: number): Promise<void> {
  await insert(request, "service_branch_overrides", { tenant_id: SETUP_TENANT, service_id: serviceId, branch_id: branchId, price_minor: price });
}

export async function createClient(
  request: APIRequestContext,
  client: {
    firstName: string;
    lastName: string;
    firstNameAlt?: string;
    lastNameAlt?: string;
    allergies?: string;
    /** Blocked from booking, with this reason. */
    blockedReason?: string;
  },
): Promise<string> {
  return insertOne(request, "clients", {
    tenant_id: SETUP_TENANT,
    first_name: client.firstName,
    last_name: client.lastName,
    first_name_alt: client.firstNameAlt ?? null,
    last_name_alt: client.lastNameAlt ?? null,
    allergies: client.allergies ?? null,
    ...(client.blockedReason ? { is_blocked: true, blocked_reason: client.blockedReason } : {}),
  });
}

async function accessToken(request: APIRequestContext, email: string): Promise<string> {
  const response = await request.post(`${API}/auth/v1/token?grant_type=password`, {
    headers: { apikey: ANON_KEY },
    data: { email, password: PASSWORD },
  });
  expect(response.ok(), await response.text()).toBe(true);
  return ((await response.json()) as { access_token: string }).access_token;
}

export type BookingItem = { service_id: string; staff_id: string; starts_at: string };

async function post(request: APIRequestContext, actor: string, route: string, data: unknown) {
  return request.post(functionUrl(API, "bookings", route), {
    headers: {
      apikey: ANON_KEY,
      authorization: `Bearer ${await accessToken(request, actor)}`,
      "idempotency-key": crypto.randomUUID(),
    },
    data,
  });
}

type Booking = { branchId: string; clientId: string | null; items: BookingItem[]; overrides?: string[]; overrideReason?: string };

const createBody = (booking: Booking) => ({
  tenant_id: SETUP_TENANT,
  branch_id: booking.branchId,
  client_id: booking.clientId,
  items: booking.items,
  ...(booking.overrides ? { overrides: booking.overrides } : {}),
  ...(booking.overrideReason ? { override_reason: booking.overrideReason } : {}),
});

/** POST /bookings/create as `actor`, whatever the answer: its status and body. */
export async function attemptCreate(request: APIRequestContext, actor: string, booking: Booking): Promise<{ status: number; body: unknown }> {
  const response = await post(request, actor, "create", createBody(booking));
  return { status: response.status(), body: await response.json() };
}

/** POST /bookings/create as `actor` (a front-desk login); returns the new appointment's id and ref. */
export async function create(request: APIRequestContext, actor: string, booking: Booking): Promise<{ id: string; ref: string }> {
  const response = await post(request, actor, "create", createBody(booking));
  expect(response.status(), await response.text()).toBe(201);
  const { data } = (await response.json()) as { data: { id: string; ref_number: string } };
  return { id: data.id, ref: data.ref_number };
}

/** POST /bookings/create as `actor`; returns the new appointment's ref. */
export async function book(request: APIRequestContext, actor: string, booking: Booking): Promise<string> {
  return (await create(request, actor, booking)).ref;
}

export type RecordedOverride = { rule: string; action: string; reason: string | null; created_by: string };

/** The soft-rule overrides recorded for the Setup Studio appointment `ref` (read with the service key). */
export async function overridesOf(request: APIRequestContext, ref: string): Promise<RecordedOverride[]> {
  const found = await request.get(
    `${REST}/appointments?tenant_id=eq.${SETUP_TENANT}&ref_number=eq.${encodeURIComponent(ref)}&select=booking_overrides(rule,action,reason,created_by)`,
    { headers: admin },
  );
  expect(found.ok(), await found.text()).toBe(true);
  const [row] = (await found.json()) as { booking_overrides: RecordedOverride[] }[];
  if (!row) throw new Error(`no appointment ${ref}`);
  return row.booking_overrides;
}

/** POST /bookings/set-status as `actor`, a forward move (no override). */
export async function setStatus(request: APIRequestContext, actor: string, appointmentId: string, status: string): Promise<void> {
  const response = await post(request, actor, "set-status", { tenant_id: SETUP_TENANT, appointment_id: appointmentId, status });
  expect(response.ok(), await response.text()).toBe(true);
}
