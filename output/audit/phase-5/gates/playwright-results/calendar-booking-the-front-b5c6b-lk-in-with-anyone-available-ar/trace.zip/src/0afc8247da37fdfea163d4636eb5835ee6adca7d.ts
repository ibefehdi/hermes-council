import type { Page } from "@playwright/test";
import { createClient, createService, createStaff } from "./bookingFixtures";
import { expect, signIn, test } from "./fixtures";
import { unique } from "./memberFlows";
import { kuwaitToday } from "./shiftFlows";
import { SETUP_BRANCH } from "./staffFlows";
import type { Strings } from "./strings";

// The new-booking drawer at Setup Studio Hawally (Asia/Kuwait, 24-hour, open
// from 14:00 at the latest): fresh services, staff and clients each run; the
// drawer books through the bookings function as the receptionist.

const addDays = (date: string, days: number) => new Date(Date.parse(`${date}T00:00:00Z`) + days * 86_400_000).toISOString().slice(0, 10);

async function setUp(request: Parameters<typeof createService>[0], id: string, day: string) {
  const facial = await createService(request, { en: `Facial ${id}`, ar: `تنظيف بشرة ${id}` }, { duration: 60, price: 25_000 });
  const massage = await createService(request, { en: `Massage ${id}`, ar: `تدليك ${id}` }, { duration: 90, price: 40_500 });
  const shifts = [{ day, starts: "09:00", ends: "22:00" }];
  await createStaff(request, { name: { en: `Mona ${id}`, ar: `منى ${id}` }, branchId: SETUP_BRANCH.hawally, serviceIds: [facial], shifts });
  await createStaff(request, { name: { en: `Rana ${id}`, ar: `رنا ${id}` }, branchId: SETUP_BRANCH.hawally, serviceIds: [massage], shifts });
  await createClient(request, { firstName: "Sara", lastName: id, firstNameAlt: "سارة", lastNameAlt: id, allergies: "Latex" });
  await createClient(request, { firstName: "Noura", lastName: id, firstNameAlt: "نورة", lastNameAlt: id, blockedReason: "Unpaid" });
}

async function openDrawer(page: Page, s: Strings, day: string) {
  await page.goto("/login");
  await signIn(page, s, "setup-reception@spacorner.test");
  await expect(page).toHaveURL(/\?branch=/);
  await page.goto(`/calendar?branch=${SETUP_BRANCH.hawally}&date=${day}`);
  await page.getByRole("button", { name: s.newAppointment, exact: true }).click();
  return page.getByRole("dialog", { name: s.newAppointment });
}

test("the front desk books a two-service visit with two people and sees the total", async ({ page, request, s, appLocale }) => {
  const id = unique(appLocale);
  const day = addDays(kuwaitToday(), 1);
  await setUp(request, id, day);
  const ar = appLocale === "ar";

  const drawer = await openDrawer(page, s, day);
  await drawer.getByLabel(s.findClient).fill(`Sara ${id}`);
  await drawer.getByRole("button", { name: new RegExp(id) }).click();
  await expect(drawer.getByText("Latex")).toBeVisible();

  const first = drawer.getByRole("region", { name: s.service, exact: true });
  await first.getByRole("combobox", { name: s.service, exact: true }).selectOption({ label: ar ? `تنظيف بشرة ${id}` : `Facial ${id}` });
  await first.getByRole("combobox", { name: s.teamMember }).selectOption({ label: ar ? `منى ${id}` : `Mona ${id}` });
  await first.getByRole("radio", { name: "15:00", exact: true }).check();

  await drawer.getByRole("button", { name: s.addAnotherService }).click();
  const second = drawer.getByRole("region", { name: s.serviceN(2) });
  await second.getByRole("combobox", { name: s.service, exact: true }).selectOption({ label: ar ? `تدليك ${id}` : `Massage ${id}` });
  await second.getByRole("combobox", { name: s.teamMember }).selectOption({ label: ar ? `رنا ${id}` : `Rana ${id}` });
  await second.getByRole("radio", { name: "16:00", exact: true }).check();
  await expect(drawer).toContainText("65.500");

  await drawer.getByRole("button", { name: s.bookAppointment }).click();
  await expect(page.getByText(s.appointmentBooked)).toBeVisible();
  await expect(drawer).toBeHidden();
  const byStaff = page.getByRole("region", { name: s.appointmentsByStaff });
  await expect(byStaff.locator("[data-event-id]").filter({ hasText: id })).toHaveCount(2);
});

test("the front desk books a walk-in with anyone available", async ({ page, request, s, appLocale }) => {
  const id = unique(appLocale);
  const day = addDays(kuwaitToday(), 1);
  await setUp(request, id, day);

  const drawer = await openDrawer(page, s, day);
  await drawer.getByRole("checkbox", { name: s.walkIn }).check();
  const item = drawer.getByRole("region", { name: s.service, exact: true });
  await item.getByRole("combobox", { name: s.service, exact: true }).selectOption({ label: appLocale === "ar" ? `تدليك ${id}` : `Massage ${id}` });
  await expect(item.getByRole("combobox", { name: s.teamMember })).toHaveValue("");
  // Anyone: each time names who takes it; picking one assigns them.
  await item.getByRole("radio", { name: new RegExp(`^17:00 .*${id}`) }).click();
  await expect(item.getByRole("combobox", { name: s.teamMember })).toHaveValue(/[0-9a-f-]{36}/);
  await expect(item.getByRole("radio", { name: "17:00", exact: true })).toBeChecked();

  await drawer.getByRole("button", { name: s.bookAppointment }).click();
  await expect(page.getByText(s.appointmentBooked)).toBeVisible();
  const byStaff = page.getByRole("region", { name: s.appointmentsByStaff });
  await expect(byStaff.locator("[data-event-id]").filter({ hasText: s.walkIn }).filter({ hasText: id })).toHaveCount(1);
});

test("a blocked client can't be booked and the drawer says why", async ({ page, request, s, appLocale }) => {
  const id = unique(appLocale);
  const day = addDays(kuwaitToday(), 1);
  await setUp(request, id, day);

  const drawer = await openDrawer(page, s, day);
  await drawer.getByLabel(s.findClient).fill(`Noura ${id}`);
  await drawer.getByRole("button", { name: new RegExp(id) }).click();
  const item = drawer.getByRole("region", { name: s.service, exact: true });
  await item.getByRole("combobox", { name: s.service, exact: true }).selectOption({ label: appLocale === "ar" ? `تنظيف بشرة ${id}` : `Facial ${id}` });
  await item.getByRole("radio", { name: new RegExp(`^15:00`) }).check();
  await drawer.getByRole("button", { name: s.bookAppointment }).click();
  await expect(drawer.getByRole("alert").filter({ hasText: s.clientBlockedFromBooking })).toBeVisible();
  await expect(drawer).toBeVisible();
});
