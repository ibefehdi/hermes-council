import { expect, expectDocumentLocale, signIn, signOut, test } from "./fixtures";

test("owner signs in, sees the shell, switches language and signs out", async ({ page, s, other }, testInfo) => {
  await page.goto("/");
  await expect(page).toHaveURL(/\/login\?redirect=%2F$/);
  await expectDocumentLocale(page, s);

  await signIn(page, s, "owner@spacorner.test");

  await expect(page).toHaveURL(/\/\?branch=[\w-]+$/);
  await expect(page.getByRole("heading", { level: 1, name: s.welcome("Sara Owner") })).toBeVisible();
  const topbar = page.getByRole("banner");
  await expect(topbar.getByText(s.tenantName, { exact: true })).toBeVisible();
  await expect(topbar.getByText(s.ownerRole, { exact: true })).toBeVisible();
  await expectDocumentLocale(page, s);
  await page.screenshot({ path: testInfo.outputPath(`shell-${s.lang}.png`), fullPage: true });

  await page.getByRole("button", { name: s.languageButton }).click();
  await expectDocumentLocale(page, other);
  await expect(page.getByRole("heading", { level: 1, name: other.welcome("Sara Owner") })).toBeVisible();
  await expect(page.getByRole("banner").getByText(other.tenantName, { exact: true })).toBeVisible();

  // The choice survives a reload.
  await page.reload();
  await expectDocumentLocale(page, other);

  await page.getByRole("button", { name: other.languageButton }).click();
  await expectDocumentLocale(page, s);

  await signOut(page, s);
  await expectDocumentLocale(page, s);
});

test("a user without a membership sees the no-access screen", async ({ page, s }) => {
  await page.goto("/login");
  await signIn(page, s, "nobody@spacorner.test");

  await expect(page).toHaveURL(/\/no-access$/);
  await expect(page.getByRole("heading", { level: 1, name: s.noAccess })).toBeVisible();
  await expect(page.getByText("nobody@spacorner.test")).toBeVisible();

  // The shell stays out of reach.
  await page.goto("/");
  await expect(page).toHaveURL(/\/no-access$/);

  await signOut(page, s);
});

test("an unauthenticated deep link returns to the page after sign-in", async ({ page, s }) => {
  await page.goto("/settings");
  await expect(page).toHaveURL(/\/login\?redirect=%2Fsettings$/);

  await signIn(page, s, "owner@spacorner.test");

  await expect(page).toHaveURL(/\/settings\?branch=[\w-]+$/);
  await expect(page.getByRole("heading", { level: 1, name: s.settings })).toBeVisible();
});

test("a receptionist is sent to 403 for an owner/manager page", async ({ page, s }) => {
  await page.goto("/login");
  await signIn(page, s, "reception@spacorner.test");
  await expect(page).toHaveURL(/\/\?branch=[\w-]+$/);
  await expect(page.getByRole("link", { name: s.settings })).toHaveCount(0);

  await page.goto("/settings");
  await expect(page).toHaveURL(/\/forbidden$/);
  await expect(page.getByRole("heading", { level: 1, name: s.forbidden })).toBeVisible();
});

test("an unknown address shows the 404 page", async ({ page, s }) => {
  await page.goto("/no-such-page");
  await expect(page.getByRole("heading", { level: 1, name: s.notFound })).toBeVisible();
  await expectDocumentLocale(page, s);
});
